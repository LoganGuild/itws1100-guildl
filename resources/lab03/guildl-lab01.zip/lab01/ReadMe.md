In this lab we set up our file servers with Azure, created our GitHub accounts, verified that our web servers installed, and setup a link between GitHub, our servers, and our local machines



Files included:

status page on Azure showing your instance setup and running (guildl-lab1-AzureStatus)

account profile page of your Github account (guildl-lab1-GitHubInfo)

screenshot of your checkphp.php page (PHP 8.3.6 - phpinfo())

Hello World page in your iit folder (guildl-lab1-HelloWorld)

Apache2 Default Page (guildl-lab1-Apache2)

