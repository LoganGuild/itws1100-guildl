In this lab we:



* Created a new branch on GitHub
* Created outlines for our first website
* Created our first website VS code
* Enabled security for our website





Files Included:

Outline for the website(Website Outline.txt)

HTML files for the website (aboutme.html, index.html, labs.html, personal.html, resume.html)

CSS files for the website(styles.css)

Read Me file (README.md)

lab 01 and 02 zip files(guildl-lab01, guildl-lab02)

