In this lab we created our own resume to use for the foreseeable future and customized it using HTML and CSS.



Files Included:



Resume (guildl-LoganGuild-resume.html)

